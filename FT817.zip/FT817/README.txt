Arduino FT 817
--------------
This is a standalone library for controlling the YAESU FT 817 
using the famous arduino. It also features some examples on what to do.


More information can be found here:
http://8ch9azbsfifz.github.com/arduino_ft817/

Released under GPLv3.
Gerolf Ziegenhain, DG6FL

Code Quality
============
This is experimental code.

