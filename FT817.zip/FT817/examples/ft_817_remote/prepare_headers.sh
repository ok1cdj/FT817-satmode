#!/bin/sh
bandplan_path=~/src/amafu/bandplan
cat ~/src/amafu/bandplan/c_structures/arduino_header.h > t_channels.h 
cat ~/src/amafu/bandplan/c_structures/t_bandplan.h > t_bandplan.h 

